使用：
.\tr.exe ./
